<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '51e1a8897c740f9638fd0b6172893f86',
      'native_key' => 'core',
      'filename' => 'MODX/Revolution/modNamespace/f5488a9866ee66f3ee0d65791255646c.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modWorkspace',
      'guid' => '6b4d43856cf1f73db2666d3b8a7d71e3',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modWorkspace/b9544b3b9bf974c7b5886d67c2d0dca4.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\Transport\\modTransportProvider',
      'guid' => '07a6c0ad999aa73e4420e848f80f2a16',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/Transport/modTransportProvider/f047658add499b6c8ebaab8488aa6528.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'b6cf9ffe5c37f58b7c5fe91bc9b2fd78',
      'native_key' => 'topnav',
      'filename' => 'MODX/Revolution/modMenu/f59135254a1c673acf76cdab1c0a2c62.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'bf51979906482a148cb1fe5cdf2cdc22',
      'native_key' => 'usernav',
      'filename' => 'MODX/Revolution/modMenu/b6e922ee96724d7393cdc9ee2ef59788.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '2f6b99b1727de41bd14ad388e77646eb',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modContentType/f34c0c1c1d1a5a0d5d4539e24fb561ab.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '076f956212858563aade44779049e018',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modContentType/d45317e5b96ada3f58dcb23befdcd92f.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '91ca516be9b9b72ca76251cb027d673f',
      'native_key' => 3,
      'filename' => 'MODX/Revolution/modContentType/fe7d0ea019b50c0e93281baf5c2a65d3.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '7bed66fc87d7ce2a471aae1c51122431',
      'native_key' => 4,
      'filename' => 'MODX/Revolution/modContentType/a9c3ac5787fffe524ebe5fc603e5bee6.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'b407df8009ee230a2450611584e68c5e',
      'native_key' => 5,
      'filename' => 'MODX/Revolution/modContentType/bc77c3efd74a8e3843134af8c3bec499.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'df8514b4b7f8c262a25c2c0efa86dfc0',
      'native_key' => 6,
      'filename' => 'MODX/Revolution/modContentType/ccbe3e7c831c7cff0f18cbb9832a44f2.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '2251aadfed80929195552b8e9916a8d4',
      'native_key' => 7,
      'filename' => 'MODX/Revolution/modContentType/2c8a95624d553b8dc93c9a4d7683d29e.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'a34e6dc4dbffe42e0fc3a338faf51e36',
      'native_key' => 8,
      'filename' => 'MODX/Revolution/modContentType/138083595c4dfdf1a32893b8d081eae6.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ead4e73feed8094853c6e5e4ce313300',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/689e741eba94561158af7f5131165d8b.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5504661fd79b917ae43e7aad1b266347',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'MODX/Revolution/modEvent/9fb2376370d86b5f2c6c2a018448cdbb.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ef3b8f8da6c74925c7bc1d77468b7484',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/87a49cd6920b94324e733456eba80618.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '742c05e310afdcba756c5036d9de9dee',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'MODX/Revolution/modEvent/ca537110721e4cabbc3cfff04802a9c3.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'dfc38a8904700b0d128038eb1605a778',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'MODX/Revolution/modEvent/b81aed09888775e526f1c70621fa4152.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '81eaa8c9d5d02916621c4d33fe857f7a',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/be92268611fb4cb05b4c1e45332a3d85.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e19aa73bb169b21c07019f6f5accc115',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'MODX/Revolution/modEvent/c5b7b083a41b7d331dfabc387af9b801.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '14228c0755d5579c5f3be4661e2e1eea',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/71d3b76fddbcbed95e4ee15097cc20c0.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1322fb745f9adf4a36e137c6582c8d05',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/6c2844f1f4ca5816cbf53e94f3e63014.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '15c6795cad79e84f511f2b5560b83400',
      'native_key' => 'OnSnippetSave',
      'filename' => 'MODX/Revolution/modEvent/e3aa10225a9c36371f6abc9b8a76ace6.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e6c9a2b0e86e77efba66dec076281863',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/323e6973d902be90373e8f88542d9d50.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f231e2cd6be625e96490907a5c8139e6',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'MODX/Revolution/modEvent/356f01c6ec3f368b27a5a088deb20b4d.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ffa8317b9b336c4cb781af47bcdacc39',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/85c25b5c389b4bb8bbebc1a30b5da85c.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '12594e6de1882141fe63d186a4446184',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'MODX/Revolution/modEvent/82dfee13b84f9420efb168edaa62fb8c.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0ac1ba8df35e8d5d3ea57bbf6da16678',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'MODX/Revolution/modEvent/b79058857fa1c97ac211f8afe49a9450.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '35e161d7dbe9035805ec3bed3ca6feeb',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'MODX/Revolution/modEvent/3f05e8b48a0b5d5f09644543b46a4f1a.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '13df9a4d005a0c0f57321a7af2365433',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'MODX/Revolution/modEvent/5232aadacc6d6e7451e74611a8f32f92.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4c308c9bb1520064315a1b8b18d6e3b0',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'MODX/Revolution/modEvent/6e71c73b12cdcb1414393377fa3213bf.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ed03e22682d926dfc72735ed78f149a6',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/43783f7ea080ef8ecc66b57c24c5eee1.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bf4bd5a9ca87e257888aec063595cd95',
      'native_key' => 'OnTemplateSave',
      'filename' => 'MODX/Revolution/modEvent/89e647cc5e41fdc4f2ac856663d1e951.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '467b2e9ba1be23e6ba3a973c074831b0',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/df1e2b057cb680413bb8523e39bd923e.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b50a728f9be65596fdfb0996594feb9a',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'MODX/Revolution/modEvent/17f1a9ac271f92de60b06b6f0a19fc1c.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a67730a544f8a3a96cc231e217324b64',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/50db219058d17011ce45736778c48360.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f4145cc87b32b34d7c12023a003a5935',
      'native_key' => 'OnTempFormRender',
      'filename' => 'MODX/Revolution/modEvent/b6714a6215e35346c1706066dc7821bf.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '01cb453c164abd7707adb72802b6e149',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'MODX/Revolution/modEvent/3a4198b715b1f0bceca0f85fdaa4085f.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '05dd44dc06db261fe30371605b04395f',
      'native_key' => 'OnTempFormSave',
      'filename' => 'MODX/Revolution/modEvent/a9a5ec16cd861bb9d1329835d33e7978.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '94a32edefe82ee54d4d5517552359beb',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'MODX/Revolution/modEvent/9bb7b96fbc0d129bada9d3943b230065.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b1ce2abf1bed9d17ee6dd3779844c170',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'MODX/Revolution/modEvent/849550dcc8a40381f9e6583b0d7562de.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '40f79426333e7529ee834828713b4ca7',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/35624e313c7fddf9b3214ac31fa2d2f6.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd997441972d9aacc3244f71fb76b4402',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'MODX/Revolution/modEvent/5db0d5ac9d27c14ef51e07583ab7ab5f.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '15ca2e078160402c1612d8008bdfc002',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/77a1293223e95027ba1055e668f120b7.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c408649507bc7a12bf9bd4eae742f090',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'MODX/Revolution/modEvent/b6195c6bfb09b387ec7ab6a403bf8580.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '181ae80ad81ef69996a7b234e0b54931',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/ebd7508c0e09a4505e67fe78e983b6fc.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd332adba8d849def79490409fc1a7f01',
      'native_key' => 'OnTVFormRender',
      'filename' => 'MODX/Revolution/modEvent/f05902a2cb9986cdf6efac24cbb63fe1.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a89d553f3203e8e11452a1f8bf447716',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'MODX/Revolution/modEvent/7ebc61e3ed1b1373573078877dd96f3d.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7cfb2182f27cc1bfcdeab87fdf2eda08',
      'native_key' => 'OnTVFormSave',
      'filename' => 'MODX/Revolution/modEvent/8b20337958e80447e4904519b2173f2f.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c2d42c059c7c12ed8f10101e1a8cac44',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'MODX/Revolution/modEvent/aaafffdc5881381e27efb8864f2480fd.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '484b9ffc14e81bb4351614c129768018',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'MODX/Revolution/modEvent/246fdbe08de8ce9f77208d68ff8a2236.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c1db7d5226e72eebdbc1a3a60aec16bd',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'MODX/Revolution/modEvent/40b8dbf094e211a4befb758242dba202.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5f232cc2e3f18c9721a98d672f92e9e6',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'MODX/Revolution/modEvent/1b0f9474700710daa159a47a7a90e11b.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '86cffdeebc1e7fcf67ad4f7112a46428',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'MODX/Revolution/modEvent/94c707042c2dbda588125637ebd0bd8f.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2b6cef10a143f376189a00ae13dcf2e4',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'MODX/Revolution/modEvent/6b6dbfcce35e106e977cf7d854258618.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd8cffe3b3d0139817c98ea81a857b815',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/8a8c2c11a0a10ecec04d05a73a30edc1.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bcb46b80d4dbf4e0f4e7210d54548478',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'MODX/Revolution/modEvent/fd4e644ef30433be6bcc029b6238d0b3.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b16c2b951e3708190081658aec18628d',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/4fd202e28699e6b67381a6ba47365156.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4f7e6e6b397724ac8694dc8a01c74eda',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'MODX/Revolution/modEvent/f33f7e8c8e7ab1a372ad923fae14a521.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6edf5e4798b814d346dc2154d49d23db',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'MODX/Revolution/modEvent/bd14316226c99773c0c5ec71267aaf0f.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ee8b5d6260a842f9d5d2c14b647d87dd',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'MODX/Revolution/modEvent/3706ffb80a2b63c15c39c0ec9ce47b89.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '91994132a668cf6a886422ea8538430e',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'MODX/Revolution/modEvent/0c4946eb3a9cd0e69fd6e32d394fdda9.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6868f53800944688da854ce40809ac15',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'MODX/Revolution/modEvent/171ec3f5d682a0863a45e0627d255815.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '15a9ed0f12fcbecec8dfa41864f20e37',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/01f82cc1d1ee1120a647900cd6c38159.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd5eff9f071f39f253281214426bf46dc',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'MODX/Revolution/modEvent/a77fe09eb5e18cae60964fa978c3a201.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9aac3505c8af1275760e18fb58d651d4',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/4fd920d81fb8c5823a1d981b79c539fe.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '84b1b25582f4f59d304953bf2484e1f8',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'MODX/Revolution/modEvent/5404bd699203e1a4739f78da45376f5a.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bc51e26c090d37a1f648409caf3496d8',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/d3ab6955838588c63cacd4c2c3fdbcbe.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ca7ce0b32a184ff9a618f653160ad6ac',
      'native_key' => 'OnDocFormRender',
      'filename' => 'MODX/Revolution/modEvent/d6c3d2358ad427c7380bd7ec8d1a593c.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'aa1ccab37aa7b5f09ad442d379c5bb73',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'MODX/Revolution/modEvent/ac40524f30c7e9401e4abc2c6165c4d9.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c4fe900dd226f1690ef268a60e115ad8',
      'native_key' => 'OnDocFormSave',
      'filename' => 'MODX/Revolution/modEvent/e7831c5a36b9fb4b614cf768d3c1101b.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c98b7a865fdb9319b5aa5224a709cfea',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'MODX/Revolution/modEvent/c6f2fd0aa8f2632c2e8ab3488802a488.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8e90658e6c205803b8b87652d4de1726',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'MODX/Revolution/modEvent/d14c2cff1a56b6cfd1824108686cf0b4.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '34f32975727b7997db6addfa8daf3942',
      'native_key' => 'OnDocPublished',
      'filename' => 'MODX/Revolution/modEvent/f8b7a11b57cec1404a5ffcfa676a4c07.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0af73f0d0542be07595e073800fb310b',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'MODX/Revolution/modEvent/c7c2ba0d2cb0e02cd699f7bcef50b9c6.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3c1498ae3494a1bfc9a33e5623c9c26e',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'MODX/Revolution/modEvent/e38b1c1fd9be0bd43a2fab39d5ecad07.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3734c85aaa1285100892cbfcc9419b43',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'MODX/Revolution/modEvent/cc48b8b1c0994d67c2c28e74f4375999.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '736a4d7fad2ca0f189beca4627e508cd',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/5be1ca29271385834d225ff99d4fd0bc.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '24abea3b24d770311ad6bb5d738fa795',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'MODX/Revolution/modEvent/2c92a05bb6fd923e313fea2f8dea0fc0.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'dba3043680e0a28c7bb2135ff927e924',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'MODX/Revolution/modEvent/cf7a7089574cf358c9e161258687599b.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f05ba3e479c69cb955880b40d74aa8a1',
      'native_key' => 'OnResourceDelete',
      'filename' => 'MODX/Revolution/modEvent/f078cf5263f12a88bbef9d76678ae1e3.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8d6cdb0c77debf5121d3860eca99d725',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'MODX/Revolution/modEvent/d5244492b04a037ed4f292a7b3e28108.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7f365904107f49fc0a548dea0ca3944f',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'MODX/Revolution/modEvent/ea2430b7a756b3ff8211eaefd58ab3db.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7be3038dba978c96a40ba2324835f686',
      'native_key' => 'OnResourceSort',
      'filename' => 'MODX/Revolution/modEvent/6ab5b399dabb900cf89ec71d72e086b3.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f99cece4736372ca91c7d04abc1f4dcd',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'MODX/Revolution/modEvent/659d879b8089c7c5b84638b24d8496f9.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8388ffdd92de81710ea31b37a912b15d',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'MODX/Revolution/modEvent/d1b4222a8328debfabd9931e16f944e3.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5730423199fa14da923212e53b3df0c3',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'MODX/Revolution/modEvent/408f7db442f2bcf192709e93e3d2e3a9.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9b4e18c213818045e8c1a540d906a7cc',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'MODX/Revolution/modEvent/ec8ba0fcfe2339c6a065a497f6c5824e.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8ad81c95740db96efc11344d60748848',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/63e62896c7278ca4004a55b5142cc705.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e0dc8579aa4ca62ba30bbc1a2bea0936',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'MODX/Revolution/modEvent/52e4b117e8ce8509cbd0f815ecf5dd93.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '80d61c542bf2fe03f89340a4b4e5f412',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'MODX/Revolution/modEvent/f6aebbab6fe716ede9c22f6f84ce8553.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0746b13b3b91f57ea46abebd1d051de7',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'MODX/Revolution/modEvent/37d44be104f84056d3aab7af31688552.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '72ddad8fdf32a2e5c4c217d3941d7e15',
      'native_key' => 'OnWebLogin',
      'filename' => 'MODX/Revolution/modEvent/269346de71b71a7fc3258b2bb7fd6701.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'cb75853ac53a8f0d6f3ed2c110ce98cc',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'MODX/Revolution/modEvent/c9cd4608ce7afc3f42a61ec27f7a2eea.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c7317c12860cb67b1306bb2782c8e02c',
      'native_key' => 'OnWebLogout',
      'filename' => 'MODX/Revolution/modEvent/3ae3a7aadb1adc2745be9fa09aeeb5cb.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e5bf6bb38f03207692a86a0efbbf1045',
      'native_key' => 'OnManagerLogin',
      'filename' => 'MODX/Revolution/modEvent/d5055eaa7d70dbc4131d0a36884465d1.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '686523e713a0c2a159566039ac0a4fee',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'MODX/Revolution/modEvent/e1b5b616629685c0334672f9094d404f.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fac5029a690e9e5ac26b21b5110e9624',
      'native_key' => 'OnManagerLogout',
      'filename' => 'MODX/Revolution/modEvent/4599efc73d1204f2cd965ebb10e32add.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e8b5d62e2286e9763344b619630415ff',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'MODX/Revolution/modEvent/3c16fb368bad445d6f09a669365452d5.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1d9cd091489898ec8eecd505b0c8679e',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'MODX/Revolution/modEvent/fe9b30d15adf557b0d6486ddcd15ddc5.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '88e868aa474338884b280823e36ccfb4',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'MODX/Revolution/modEvent/4d1ed554a7dbe70d60748ef23d08382d.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '58c7aeaa50b1f9397a47cbc6d19bad99',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'MODX/Revolution/modEvent/d6baf22a0ebc403e1c66b92883daba92.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bf7e9942c369c8da191c9489c4fc7357',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'MODX/Revolution/modEvent/59025469ac83a5199858d91aa8df4244.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '708a039920897f6defcd219128a6285a',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/b9d98f429494365d78f8f9e544fb712a.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd68b551668bae3eca3ab53648234f358',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'MODX/Revolution/modEvent/ae1ac9efecc9b9eb2e0be922ac7e7259.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0cee0e02b114b0226ed8f8bcd6177660',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/fbed3dc1033cf19c754b477550840cf2.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1727803af4721067978a2dfa1caf6691',
      'native_key' => 'OnUserFormRender',
      'filename' => 'MODX/Revolution/modEvent/8e38fe6f07345173a71780f4bbfa7314.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4c55ab0ec6f72bc1ad83629ee821c392',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'MODX/Revolution/modEvent/3c194551abeb7add3c4907657a10a8e2.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c637eaa81b677f93b559659015227516',
      'native_key' => 'OnUserFormSave',
      'filename' => 'MODX/Revolution/modEvent/42e8c862784cebc72c33c147ab1123e8.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8f57cfb2afe032f4cf3f63c952526c52',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'MODX/Revolution/modEvent/c7489ccf49c412994165bb04898503cf.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6a3c73d6c38b91a9499917a64d80d3dd',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'MODX/Revolution/modEvent/dcdc43df4bec4b4b47631a17bdd080d4.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd1288391ff34dbcbe2aec27769fa03ae',
      'native_key' => 'OnUserNotFound',
      'filename' => 'MODX/Revolution/modEvent/39fdb295865a5a3958189cc3024db694.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '00e91aabed9219cbdca27c6cb9c2b06c',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'MODX/Revolution/modEvent/f21933d25436f05faab23b5e75453726.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1bdbe5c5685e96b3a55d29df4eaed9f8',
      'native_key' => 'OnUserActivate',
      'filename' => 'MODX/Revolution/modEvent/ae78a7401d4bcce8bf0c52aaa9b7e943.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0ba37faf4736ff1fcb461a691b951ff4',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'MODX/Revolution/modEvent/28cbc1af5958b54c01597c3456c81ab5.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e5e664b4b9f1624d76a0b66e3e98d2c7',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'MODX/Revolution/modEvent/943e1289465fe4b71cabf5163dc4213d.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f3d7aa52af8b60313daf2dc0feefed02',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'MODX/Revolution/modEvent/831e9c210d8a51d8ff49fbc6f4ea412e.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '80b8744f762670430efa3f5bec6ebbdc',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'MODX/Revolution/modEvent/5e7c286651012cbeb51884523deb4694.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5a1e142678c6f0f876baf7b13cef2dcf',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'MODX/Revolution/modEvent/0c74327a3ca7cf4419726379795751e3.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '51b5a163354d964922066c49ba974af0',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/c7e5e75528d196242014fffcd3ab6478.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'cfffa9bef2f2e277fc7a2f15eb0d56ff',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/f6de820f981c2387c104dd0a4ade37e8.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f57e15c316f14520741a1746682802cd',
      'native_key' => 'OnUserSave',
      'filename' => 'MODX/Revolution/modEvent/e232ec9485c136f01b9baedfbc9127b4.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '949fce7de9b3e1dc593f2ae11b6ec522',
      'native_key' => 'OnUserRemove',
      'filename' => 'MODX/Revolution/modEvent/0277fb093b46a112943d1ddf3fab2e37.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3023ecd604d76358e0210d300ad376be',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'MODX/Revolution/modEvent/eb61af02e35f0f785095104b3b937e5a.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c2faeec35278bd6dd84d7876f878be5b',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'MODX/Revolution/modEvent/21a8f4c21ca85611898e6aabb8ab57e6.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '45fb544a2911ea569a55eba17293795a',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'MODX/Revolution/modEvent/dba733f8cfca42c75ffe53fba8b2cd98.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2ded4f60d6aa397064a05b29474b565c',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'MODX/Revolution/modEvent/acb2760a28f5e090d7e07f91d800f591.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'af8db9505ba3d979430b942b692a96d8',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'MODX/Revolution/modEvent/0c9302903db362b95ccc0dde07851468.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bb4f9f0ddf45ae44b6e30b9815106361',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'MODX/Revolution/modEvent/e90c8c987c8a5e4f13ed609a8efeee33.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f4983c3ce8d5f1fcbf38b5197a67e104',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/4d84eb50595000e01cc03944c93c4063.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '120f204752f5619bae76b9526c00eda0',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/e0b550688bdae4fc47a16340a4b226ce.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7db21183dcf01113051d9c38562c99be',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'MODX/Revolution/modEvent/41583b99145a411e192aa1af666496cc.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9486184406c076841eed34faa5c3e8ab',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'MODX/Revolution/modEvent/bb8700a2505a5a90011663bc364dfe0e.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fffdbf38df9231975d5b9c3a8e9990de',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'MODX/Revolution/modEvent/cf30a13063c273976f5fd3d8c0af5262.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '48a3e54fa55b5870daba998319cbc6ff',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'MODX/Revolution/modEvent/246e14398646941753675b9be8e81c79.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7d7271de922a2d75334d7a7e3deca0b4',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'MODX/Revolution/modEvent/fd811804bbaaa9189dbe3db9e4d10dcc.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '80b7a12e2bbc8c7884e0dbf883265c02',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'MODX/Revolution/modEvent/79d7078d04cb9259c611f0894e99309b.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'dd822fd00e7bfa7769cb5db7b70a33cd',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'MODX/Revolution/modEvent/ed15678a9610fdaa5b20323a2ec7334a.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '65e176fa470ac44dabe67cadf647a1e7',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'MODX/Revolution/modEvent/c55e925f1eec639c806b2c9931a82c0a.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4cd95f44f61a130d68abebed702ce324',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'MODX/Revolution/modEvent/1b8cb2f79b6d9c22ae7523fa05e880e9.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '74fc546a94cc89b9b5765efa49d2dd14',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'MODX/Revolution/modEvent/b5b19bd5a1804ea381578cae8e4c53cb.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9563d5b6aa7362cd772190c225fdb979',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'MODX/Revolution/modEvent/066f0d6c9cdef9eabda4ce8afe52803a.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd722e89d0d824847e9c57d71642b0f10',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'MODX/Revolution/modEvent/c3a8c39e2ebf3d26560dc6df3ccdc1fd.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'db1234e92b649b447ff287a24907e5a8',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'MODX/Revolution/modEvent/cbc7f3f025774a2cbbe8c4054264e94a.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '28bd0c3d2baf86558cbe95ae5c165471',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/5fc2bcce3e5922450bcb82dc27d3b062.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b9f1dc4e5e9546c36df78ac18072ec88',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/2fb2e2e25253a7db290eb8413f1c8d57.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '91803c0a86df08957238f54142983b38',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'MODX/Revolution/modEvent/1dce06d6d0bb5eb4c096e2d6fd8de182.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1cd3577c44fd97dba326344902e09f2e',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'MODX/Revolution/modEvent/0909d147a3c764cd20159054cba37831.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4793d8e4a8b97e0e91160e6b71dc37ee',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'MODX/Revolution/modEvent/4f2e86f338d3e8309e37fa0be1e579d3.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c82ec0ba6ac036f2d3f0bc19ad915e83',
      'native_key' => 'OnWebPageInit',
      'filename' => 'MODX/Revolution/modEvent/9e5671900185c90ddceaab897bf149b8.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3749eeb49b2e34e5db8b6f41e18b1b06',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'MODX/Revolution/modEvent/589cd151078fda01a8bcff44259b9657.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '50fa18ac158c386596e836cd4846d37b',
      'native_key' => 'OnParseDocument',
      'filename' => 'MODX/Revolution/modEvent/6ea8bdf3929aac5e94ed57c2ddaf48c4.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '726d287ff9dcdcaed4e83d3cf2527756',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'MODX/Revolution/modEvent/133967b0a418b153abfd291b85fa81a1.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '98b4bc0919730f97df53af15ebe63a3a',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'MODX/Revolution/modEvent/ff8d9ef31a090687bdb5a2bf705f5ad8.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'afd0f4221afb3f721be17c13cd6a60d0',
      'native_key' => 'OnPageNotFound',
      'filename' => 'MODX/Revolution/modEvent/86d0e4b10de731c0b1073f1ccab4891f.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '09b2d3bc364c7d1870e3aa81ada72bbc',
      'native_key' => 'OnHandleRequest',
      'filename' => 'MODX/Revolution/modEvent/b14463fb6daeecd196a3ec7a01b9e672.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9eed5cce85bacf5d0b4b5a762bfc015a',
      'native_key' => 'OnMODXInit',
      'filename' => 'MODX/Revolution/modEvent/8f25d3c5030c89b7f967b0ed315ed21e.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8ac4c818f242d71f812d108ef6906cb9',
      'native_key' => 'OnElementNotFound',
      'filename' => 'MODX/Revolution/modEvent/f38bd2c273836504333408260395452d.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '05314a9b950b70c82fe27a16ef1f53c0',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'MODX/Revolution/modEvent/bedd3f8aaf6720df5079e4816f1d4ce3.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '85a0c73522cec10d224a30fa4bf38244',
      'native_key' => 'OnInitCulture',
      'filename' => 'MODX/Revolution/modEvent/48d0feaa64edcb3eccdf5a29fbb6ac3c.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7273163ba27521d8cd97a56981eb61ef',
      'native_key' => 'OnCategorySave',
      'filename' => 'MODX/Revolution/modEvent/ac92311dcfce517266a799291595a5fa.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '385284e20881d64940af10bd41483f63',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/6c7f0e061919411c2fe045725bb22fff.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7f22937cc36988a2f7140000cf497026',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'MODX/Revolution/modEvent/acddef58e088c6bb1a203b09861afe02.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'eb7cbf0881d18aecc452094e403f018b',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/218428dd57b88cb1a39dcf58c60eb78e.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '081f0192eb5f20e715ce740d414ef505',
      'native_key' => 'OnChunkSave',
      'filename' => 'MODX/Revolution/modEvent/ec4f736ebf026c8d54f95522e6f43b71.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '91a68b5a4cf10b0a3899079c66cb3ac9',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/7e5480f0fd835f68597425286927e1cf.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f616c85f76ce2f3cb6b91862c4b96174',
      'native_key' => 'OnChunkRemove',
      'filename' => 'MODX/Revolution/modEvent/93d2b4280aa97ad0164091f27d1074aa.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a45a04106d3ae53539030352d2656a37',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/c403703e049c9878f7c5dab8ce4a3419.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0c212699691950854c1c53b31ea7a56f',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/381b42d7ca1c9a0660af92509974da5a.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2abc5e7fd11d14ad11ff3e1f28a61d3d',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'MODX/Revolution/modEvent/549804b4c54f77431167d74b7a3f8b83.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9208e6a8e03d2492246374c37bdde6ae',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'MODX/Revolution/modEvent/ff7005cb7312b11104b74d245a8e109f.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '578cae34a96a5b7b9f9d631c32a4adee',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'MODX/Revolution/modEvent/74092ac6369a1aeb44442973ba37a2e0.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9ff01818634bcf814988d32fab77462f',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'MODX/Revolution/modEvent/30d3cb3bf19181b891ad070202443a64.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'aef76af9f123e1d8a16ab9c7abfa2726',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'MODX/Revolution/modEvent/ba160fe0f6ab130495e5a05eb4ae0b76.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'da33c45ebb62baf3f20019b5f076ea72',
      'native_key' => 'OnContextInit',
      'filename' => 'MODX/Revolution/modEvent/0441e57edaf349826fa174bbc3e2da1a.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '127e1a6d18588719355e4a2756b27c2d',
      'native_key' => 'OnContextSave',
      'filename' => 'MODX/Revolution/modEvent/b0ef85e3c30b754ba77c6764abd83fed.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a7b6226ce0246da69543cf7282e8f763',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/b214fbd3f683d5f52be4ed03bf699af9.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '79e2f521bfbd48ee9436641ea327293f',
      'native_key' => 'OnContextRemove',
      'filename' => 'MODX/Revolution/modEvent/81df4afc7a71d255803e2b256e7b15db.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'dbbb63967b524b7ecf21bb7fd56e9358',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/bcf424cbc69571491156849fa704fae8.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '21e811681de5d77ba5acc06a8c322d83',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/e80ddda745ad3bb8ad38f192f4641a04.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'defaa339eebbd139bf7d1a65f6632b12',
      'native_key' => 'OnContextFormRender',
      'filename' => 'MODX/Revolution/modEvent/4ff2aa9a72c994daf8e801ed40624183.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9384b195464774dbcfdfaea71b20e9c3',
      'native_key' => 'OnPluginSave',
      'filename' => 'MODX/Revolution/modEvent/d553053b0935dafd7a0e8ec70909131c.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '59464726181cac1cbee11e5bdc4d9e36',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/fb8f041f35aa09defacc14c9eee3a87c.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '74d029bba001590438e79c81e06b7f58',
      'native_key' => 'OnPluginRemove',
      'filename' => 'MODX/Revolution/modEvent/729c963a52a40ae6074fce44f89c6118.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '640916af3700cd6b10b3ce02603098a9',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/c13f6a51d4fa7e53234ccfd34d968cb3.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd4ff5068ec664e57a486221133f2b9bc',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/7466df86f9e9de6e4859c12644f3fe77.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5eb2f606b530790377836e16e35420f2',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'MODX/Revolution/modEvent/3eb9d87cc63881431e2539752ff07331.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd9fc741eafae94e4aad5e8fef611f1fc',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'MODX/Revolution/modEvent/ca0805e136d6a2ced9a3480c5ad77683.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '58acfc6012a45c895baef74bbbbfc4d0',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'MODX/Revolution/modEvent/f49c7d92bf2663b1125da3529d37394b.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd85d04389ee689b9768db69348e7b3a0',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'MODX/Revolution/modEvent/5f55d8367de12e7395b221c9e92d8dad.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6f88b8c57797eb6f9d8ea920e97b0a8f',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'MODX/Revolution/modEvent/b14d0ff98a169cb5b17be5ea0b923c97.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '55918496ddee5c6f699b092e64019f9a',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'MODX/Revolution/modEvent/f2bb6893300713758f82bea594821475.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '575260fcf08465be601feba6329933e9',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/0a32059762f63b0825cbb561a21ecc95.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '06ac6078426132f4f4a5184a748cab5b',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'MODX/Revolution/modEvent/28e1ec1a042cfa92edc64481e358f322.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '35db493386d08861ab1d3c3fc2ad27dc',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/486716bb5470448865efe01f3a1af589.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '11f431333922488a468de5d1f703dbd3',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'MODX/Revolution/modEvent/14b7e066b3e2db677147624421095e41.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '77aac7659b27d680f2838da448ae65c8',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'MODX/Revolution/modEvent/9f76b5e72702d7dc9637a46e040a1a75.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '68334cb1515fcfecdaf3419feea4cfa1',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'MODX/Revolution/modEvent/4aaa97104ff842af74d89bd9e26b3bde.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3e5e89f8b95838dedfd9df8bc880328a',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'MODX/Revolution/modEvent/c73d4472f3398e293cad114cb30e1a4d.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9c75771d473a8c11d25606f1c8a51251',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'MODX/Revolution/modEvent/0abbf4770f286393f6dcc24be879fc55.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'aec8e99bff5fa7fcd19571266d60007e',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'MODX/Revolution/modEvent/c66ca5948e91f18212dd40b4b706dd1f.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0144dabe08607c158f2528c11b6479e3',
      'native_key' => 'OnPackageInstall',
      'filename' => 'MODX/Revolution/modEvent/44d17bb922ea37aac84e8f73bbd70e07.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2e18dae21a9e8c055435786b39d61aa5',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'MODX/Revolution/modEvent/f39c850223795c5a0113d2c1a3d6c52c.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '71cb3d9d8f71ca5c9f0548693a8ddc0e',
      'native_key' => 'OnPackageRemove',
      'filename' => 'MODX/Revolution/modEvent/8e253556512bf6a184aff8480d0a9e13.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4f92d84ef5112604c9abc67d92683916',
      'native_key' => 'access_category_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/76287442055c02b37e5eec9cc6a84ff4.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '59bac0f927b3a98f59c1fffaa70cf952',
      'native_key' => 'access_context_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/527677cec05a922fd911c47742e7292b.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'af345304f524eed540ebcdbd49c6c6a0',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/6897c042290e0b7d585b0282bd3cc9c4.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9ee95cda4f3754344f9b3be70c12bf95',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'MODX/Revolution/modSystemSetting/4ceee4ccefe5d313778aeaf3c26f51ef.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7725adca23d7adffe9c576e334d8dd3c',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'MODX/Revolution/modSystemSetting/f4975006e862de0f1ae777f2827bc44a.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9d214ed34a94293eb76a8a60cc11343a',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'MODX/Revolution/modSystemSetting/7db398126df90f979e7665d2246dc710.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '24c33e08f49cb3055be9f976d4adcce4',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'MODX/Revolution/modSystemSetting/3457720f2acb7d17e3b2c0136987cf01.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f2d1e3af885d21fa29b5403950f27f1e',
      'native_key' => 'archive_with',
      'filename' => 'MODX/Revolution/modSystemSetting/8b81d49f8c2c81fd66390dfd7817bdeb.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2239b8f4284606d0ecb671554ac848ce',
      'native_key' => 'auto_menuindex',
      'filename' => 'MODX/Revolution/modSystemSetting/d0dbd2c27ebfe4594619503d0131aa4a.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9106e51bbe80d619d693c4e193619950',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'MODX/Revolution/modSystemSetting/ed57371115266db2eec976100fb604c1.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a9048b5d9f4326e3732d205ee8153d29',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'MODX/Revolution/modSystemSetting/6b5b9750a0e3ad3bff6a883a8936c277.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '28a2512328dc06105c40fdc275fccfd4',
      'native_key' => 'automatic_alias',
      'filename' => 'MODX/Revolution/modSystemSetting/f8733a98cabd7bda9cbde9d70b630676.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9f876966b20a09dd235469c05ecbae4a',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'MODX/Revolution/modSystemSetting/22e1bd215fda7311cf2f912669ffdc0c.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2425133d5a5b2716ab956fa58c3f5d27',
      'native_key' => 'base_help_url',
      'filename' => 'MODX/Revolution/modSystemSetting/92766538c931559a9cdbdbc8ef873e8e.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f95f2c552bcd4cc5e97bb2eced688e85',
      'native_key' => 'blocked_minutes',
      'filename' => 'MODX/Revolution/modSystemSetting/fac115240ad6a01c2b859cac4bb38f84.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '22732ea982d8b755ff012ef43acbd541',
      'native_key' => 'cache_alias_map',
      'filename' => 'MODX/Revolution/modSystemSetting/34eca146a4692f8e29fce2181e251d3a.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0dc1128c9e2c6b06e0ae74ccf8f4c197',
      'native_key' => 'use_context_resource_table',
      'filename' => 'MODX/Revolution/modSystemSetting/e7488b174e4dfaf426464b3599f4acd0.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ff4fa62d87c95cc29e2b0f0c03afc9da',
      'native_key' => 'cache_context_settings',
      'filename' => 'MODX/Revolution/modSystemSetting/3d21084bfc99d449312ce99f33df1083.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '236e59265554c2658de8b1b887186750',
      'native_key' => 'cache_db',
      'filename' => 'MODX/Revolution/modSystemSetting/0ec4b30dc80f9aeeec40198401c7c27b.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '302c016e59b4f82b4b242e3681de7645',
      'native_key' => 'cache_db_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/ade4d72f0ef17b7b0aa0aa053838c4cc.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '220deff7ddc6345e0d7b00c8617a4c0b',
      'native_key' => 'cache_db_session',
      'filename' => 'MODX/Revolution/modSystemSetting/2cf8654d36cb02301465ad276796b72d.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6edbebfb47e1e479956ddf8df677e57a',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/f119c88c8a93841fb9a71ab39aba51fb.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2f8060773aabb1e15e852aa83c3d8a78',
      'native_key' => 'cache_default',
      'filename' => 'MODX/Revolution/modSystemSetting/736cffdf0e5310cd73e03cb6c2c5230b.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c839cfc5fb30d5de02639b7c12ef5f22',
      'native_key' => 'cache_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/ca0766594bb82d5e94115ce4f090a253.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e373f4d794062621e7211ad6250f98e4',
      'native_key' => 'cache_format',
      'filename' => 'MODX/Revolution/modSystemSetting/cab05739c99d10caa711e03c44cddcd2.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7c08089c3fcf9011d1f9c0b6d5f0c380',
      'native_key' => 'cache_handler',
      'filename' => 'MODX/Revolution/modSystemSetting/e1914c9a731d362736790d65abe381fd.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7175dff503cf7663ce7a552a1095fb2e',
      'native_key' => 'cache_lang_js',
      'filename' => 'MODX/Revolution/modSystemSetting/5d0145f7718249dd46d9e7597224a1c1.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '35ef360d96160e1fb7d21331528176ce',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'MODX/Revolution/modSystemSetting/441884f1793668e2f082ac521136b1ea.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dc496ed01b153d37056425e87bca8d59',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'MODX/Revolution/modSystemSetting/d29ad25fda33ff09963c5089e5a3d1a4.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '98b16ea9ba9f1ae8909f76e95ee0aa0a',
      'native_key' => 'cache_resource',
      'filename' => 'MODX/Revolution/modSystemSetting/1be72fbca366b45ddbaa1d7fb544cf63.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3c4cfd8f37508db41edace3235b24337',
      'native_key' => 'cache_resource_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/993c324240c678186f5ebd2686fc6528.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f55eb4161916b30e1a60333d06ecf82a',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'MODX/Revolution/modSystemSetting/3cc1b3c5a18518357a94f5592404adf0.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4dec4b2c36e72711ad899bf53d29f0e9',
      'native_key' => 'cache_scripts',
      'filename' => 'MODX/Revolution/modSystemSetting/03e18cf348bc4cf3c18b1d78d003c7c5.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '11542b33c4f01d5248c1561cade2a9c6',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'MODX/Revolution/modSystemSetting/c56260eac299f0e9f2924cecbe6961cc.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9337ebd7426ebca27ec5001eb844be12',
      'native_key' => 'compress_css',
      'filename' => 'MODX/Revolution/modSystemSetting/c41071ac0a7288058cd8fa99c3c5a73b.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a79f0de86d34b3d2db083660178d2368',
      'native_key' => 'compress_js',
      'filename' => 'MODX/Revolution/modSystemSetting/9a66c71cbf8b350a00cd017e35bf15e8.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '600298daea79b6c975e69c77ab818477',
      'native_key' => 'confirm_navigation',
      'filename' => 'MODX/Revolution/modSystemSetting/7e243c9694f0e319e96c531a3c3b4940.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3b92ddf6cd9374aac45c635bc0045082',
      'native_key' => 'container_suffix',
      'filename' => 'MODX/Revolution/modSystemSetting/b1d777bbe2c990ad65c71cf0ea4aa1ed.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b9d9a883331b001a2d4b2ac6ab5a35c8',
      'native_key' => 'context_tree_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/f2d5eaada114b262f0bfa98417a6f707.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c5bd490f0eda389f50deca99a19e098f',
      'native_key' => 'context_tree_sortby',
      'filename' => 'MODX/Revolution/modSystemSetting/9384433d70f09a259b9d628659cfb592.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5b4f30c8dacf53037e3639f76b242d8d',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'MODX/Revolution/modSystemSetting/08faae5e75b0e7e19cd1893988bc7573.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c5a51604263cf5686a63edc1e7122ac4',
      'native_key' => 'cultureKey',
      'filename' => 'MODX/Revolution/modSystemSetting/cbb8c7aaca37c1b665603b341f3c9e41.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4ee40387125c1398f2434c502b935475',
      'native_key' => 'date_timezone',
      'filename' => 'MODX/Revolution/modSystemSetting/dc667c24ee8ccef8b7ca07554661679b.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bb7aa051e5f720f9792b89ad6e783f02',
      'native_key' => 'debug',
      'filename' => 'MODX/Revolution/modSystemSetting/016f3d48252469a9166bac39cfe33cf0.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '14a683a00921a5f3abc97d4e000bdb28',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'MODX/Revolution/modSystemSetting/97ee7d5aa6e2a3b2c394b06118806316.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '52ae5d00eb99f42be415f72f1b01885b',
      'native_key' => 'default_media_source',
      'filename' => 'MODX/Revolution/modSystemSetting/43fb3cb5da78066e220dd5f86d3b9f19.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f0614e8d43eff4627f1ccc55d30a01b1',
      'native_key' => 'default_media_source_type',
      'filename' => 'MODX/Revolution/modSystemSetting/71c3ef4e6434a2a825bed987ba568077.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd34a036d9a1f42e916ad14ff586cae82',
      'native_key' => 'photo_profile_source',
      'filename' => 'MODX/Revolution/modSystemSetting/d3e5139caa9fda33b0b573c7c68171a9.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b4a8fbe315e22b539195229a17897b55',
      'native_key' => 'default_per_page',
      'filename' => 'MODX/Revolution/modSystemSetting/f1af6fc3dc4ad98432d3b79fbac61521.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ef0387abe4be9cc500aa4ada63c1a58a',
      'native_key' => 'default_context',
      'filename' => 'MODX/Revolution/modSystemSetting/bfb70d2c39717ed8ec615878c62793ff.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '15303863614e1aac01929c1b0cdafbf6',
      'native_key' => 'default_template',
      'filename' => 'MODX/Revolution/modSystemSetting/9e9104981e9060f82681e0c4132eb590.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '38ff746c2dbce99f44a8510bb2917b90',
      'native_key' => 'default_content_type',
      'filename' => 'MODX/Revolution/modSystemSetting/62e424e9776f534f3418d1b153da6aa1.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0b0ecb0fe3c9ed024cad69a872a5fee0',
      'native_key' => 'emailsender',
      'filename' => 'MODX/Revolution/modSystemSetting/529d9932a539b56207a144a4d000cac2.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '84812552d937a1b39b014db7812ac9f7',
      'native_key' => 'enable_dragdrop',
      'filename' => 'MODX/Revolution/modSystemSetting/2f47e119906aefab94998a6741c423ec.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '55ea6eee564696e26e76f02e66206fef',
      'native_key' => 'error_page',
      'filename' => 'MODX/Revolution/modSystemSetting/3a16e9e0134e67e8563ce43cf55b83f5.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f769c7868ff37250305b5b9ad5214aee',
      'native_key' => 'failed_login_attempts',
      'filename' => 'MODX/Revolution/modSystemSetting/03f3db2921ae7011d82b47493c797b5b.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e6f92bbe31a0e677119679fd8e03b80d',
      'native_key' => 'feed_modx_news',
      'filename' => 'MODX/Revolution/modSystemSetting/750179ddb910dfe6edaa0ef2a7be5668.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b63ad7ecfe1056b08cf5165ccce5a086',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/f85cb71945a4fe2d43bea80cdbdd5b27.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8955a63707e422ee203ce5447b749085',
      'native_key' => 'feed_modx_security',
      'filename' => 'MODX/Revolution/modSystemSetting/3690b30c4f7e6155a62dbe58230875e4.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '15b21b0eac5d81a6522e57cb8ecfe906',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/311b566ff5813dbd7f3284caaabe926a.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c4be05d7e11690a734895e979ef9ca4d',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'MODX/Revolution/modSystemSetting/a2e2891a6680352c41c0c3ec7b0db53e.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '92609e6c48e4ffcbc202a53edda5fc59',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'MODX/Revolution/modSystemSetting/08db015c88c8ee6232989dcfdb9455de.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '43c49ff7e42d9a4f141b7cb1d8aeaecc',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'MODX/Revolution/modSystemSetting/94e2522cb31e5ffbaf9978edbf03de01.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '66074dea61ebcfc6a805ea30ddff58f1',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'MODX/Revolution/modSystemSetting/7ac8493bc83f16183dd1d5f62a3f0ce9.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8fbfef5a7081d0460ae4ae5a6461ca38',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'MODX/Revolution/modSystemSetting/c9b4a8beca4e9b957112254f25cf4c57.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '508f0a196303b11a4d23d98e148c9ec1',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'MODX/Revolution/modSystemSetting/dca89731e04d129c8d926ebb31d16962.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0ead82db348a9dbbd130e1d737511866',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'MODX/Revolution/modSystemSetting/2ba0e975131e7dacd450cefed33221ae.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cd7f3506d0478210bdda37319e17711f',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'MODX/Revolution/modSystemSetting/5a00ba2adfd71045baeb34f4a807ff5c.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2a50a878210e4ba532ec2e2806878733',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'MODX/Revolution/modSystemSetting/32d9d6506a4735ca487fd102b263c9d3.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ac2b1bd54057dd36f9229c48d1526428',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'MODX/Revolution/modSystemSetting/c3beb4c46edbaa1fb1d5b7dc6ddd883f.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0057fc0928ed1cde4a7bf1f5f70add2d',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'MODX/Revolution/modSystemSetting/6a2dd8c0bc8ab7f18026b5283f54042a.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e762803786ab06f064714ac8e7611f0c',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'MODX/Revolution/modSystemSetting/1018d33836c2308b64493226e0ea24ca.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '82f24db8619565926017611105cc1487',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'MODX/Revolution/modSystemSetting/fff58cf53197e5f6714c4325726ec19d.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f3df48a2b020a5d23755b454ff988e30',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'MODX/Revolution/modSystemSetting/e194638f6083dfb7e26856eb840ff171.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bc999bc4d8d3dbc47db08e7d03e083a6',
      'native_key' => 'friendly_urls',
      'filename' => 'MODX/Revolution/modSystemSetting/ae518e77c72ad1ba6da87f6e61238e2c.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'de414d7a20793cdcf6ebba3d82a62cd7',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'MODX/Revolution/modSystemSetting/890addc329d1c9f9dc4bc55b49376eaf.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '09eba1e7dc2ee294ea3550dd17a76f67',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'MODX/Revolution/modSystemSetting/9abbd65d6b9ea7fdf6e52c16908d277a.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f380c4ce549d9dc492fbe77a18b697fd',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'MODX/Revolution/modSystemSetting/fb06ede2a9b83570aa5602881764a589.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '34ea6c4b7d97487000af14f64cd8d775',
      'native_key' => 'hidemenu_default',
      'filename' => 'MODX/Revolution/modSystemSetting/bb4e94b8a4340aad7b79b0d0e75332dd.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fbdc018e67ac10afe0de0b8b41bacd93',
      'native_key' => 'inline_help',
      'filename' => 'MODX/Revolution/modSystemSetting/8b90b06e30b9f493e5bccf6654e5b073.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9e3eb2af28a5053d58032df8a590f893',
      'native_key' => 'locale',
      'filename' => 'MODX/Revolution/modSystemSetting/bcb66749877d59dd2031af27f0417299.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1499133d6ea2561050fdb5ce103f27b5',
      'native_key' => 'log_level',
      'filename' => 'MODX/Revolution/modSystemSetting/2b142c57af36d7249ea16ab9eb7cb657.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2fc951ba4034893aa20c0a60768dcba0',
      'native_key' => 'log_target',
      'filename' => 'MODX/Revolution/modSystemSetting/be01f6a1962a8ba41a0a2371b43ac240.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2037528aca5734709c7ac6b0e1687ba7',
      'native_key' => 'log_deprecated',
      'filename' => 'MODX/Revolution/modSystemSetting/adc95b9b8e8871b08044b08ef859e329.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e8b402e2e151da8605c202c2fea20d5e',
      'native_key' => 'link_tag_scheme',
      'filename' => 'MODX/Revolution/modSystemSetting/7e1a29feb3b663b260d0f6e8f69ef293.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '60a3d7929faa59d68a9912c3ceca2392',
      'native_key' => 'lock_ttl',
      'filename' => 'MODX/Revolution/modSystemSetting/fd030984e45f580a34a4fb8bc400a244.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fcec7ac4eb2db27ba277cb104a79e2b2',
      'native_key' => 'mail_charset',
      'filename' => 'MODX/Revolution/modSystemSetting/c8fdf53ee66a574c08a4eda88d48b858.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5f6ae804df12cda0cf84d2a4f81b15be',
      'native_key' => 'mail_encoding',
      'filename' => 'MODX/Revolution/modSystemSetting/501c366cf30bed5226725da8822a390f.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b973cb82e1db22131a569e1242886166',
      'native_key' => 'mail_use_smtp',
      'filename' => 'MODX/Revolution/modSystemSetting/5a1c79a0984b734b71d53d5545aec097.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b35990804fa268fb44d1bc60f7034a75',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'MODX/Revolution/modSystemSetting/487356e68f0ba98a21ebccc9e6718ce9.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bba705c2c502f5292ea55a660eee542f',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'MODX/Revolution/modSystemSetting/0eae9cc50923f388c36c34ccb2816503.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '20823009dc2a138a32cfe0642005243b',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'MODX/Revolution/modSystemSetting/e37fe90c62c21e06c2b0c86f51b56400.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd596675b49db7b7b3f35ad1cfde46c2f',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'MODX/Revolution/modSystemSetting/47fe0d8ebdf00e0a9c61c57e5f5e07ff.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cf43de4b6b2d3c38a7e54a776d01c6bf',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'MODX/Revolution/modSystemSetting/6551b9768244fac4d718c3e1626c7093.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4d3552f63c9ad22f5328a373ae4e37e2',
      'native_key' => 'mail_smtp_port',
      'filename' => 'MODX/Revolution/modSystemSetting/8f101bf730b86192869bca5f384b5bee.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b6f795ff124505229690fa19c05b5d2d',
      'native_key' => 'mail_smtp_secure',
      'filename' => 'MODX/Revolution/modSystemSetting/93656fc4cb85773281dc0907868308ef.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a68587a2bacb6797cb11f27aa557bce6',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'MODX/Revolution/modSystemSetting/a048e2a879d72a54be5bf2ff2a4610f3.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '91f7f269e5368d3c43db5aab381f6837',
      'native_key' => 'mail_smtp_autotls',
      'filename' => 'MODX/Revolution/modSystemSetting/a9d60b317ad45fddc7336d44df231b96.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd0c231b926b509b27cccf78500a5cbc7',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'MODX/Revolution/modSystemSetting/9adca10c73ab50a35879c315387d8156.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd309302e6732afe87c72f4a347da4e3f',
      'native_key' => 'mail_smtp_user',
      'filename' => 'MODX/Revolution/modSystemSetting/944dbdc6b1fec625cb95e629a7e723ca.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4bf6c434f56104b2600f1e4edb616a5b',
      'native_key' => 'mail_dkim_selector',
      'filename' => 'MODX/Revolution/modSystemSetting/7571021a5ce4779f89a0f7b96f97f08a.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '04bdf3f5833badd777be2aeb29fe5503',
      'native_key' => 'mail_dkim_identity',
      'filename' => 'MODX/Revolution/modSystemSetting/99b3e5f1122ccd31e6644585253aed86.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ac052f67b6ec817313178974add041f7',
      'native_key' => 'mail_dkim_domain',
      'filename' => 'MODX/Revolution/modSystemSetting/79c8b4e0dc6791c263a4f2686920f1b9.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '78bc514e99b7e6849bf563eb6874ac1b',
      'native_key' => 'mail_dkim_privatekeyfile',
      'filename' => 'MODX/Revolution/modSystemSetting/d22fae1d66b14a84c56487fc82434757.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '21f4f3f8ab8d6d7fd3380d5376e10eb8',
      'native_key' => 'mail_dkim_privatekeystring',
      'filename' => 'MODX/Revolution/modSystemSetting/6edccea9c49ac83db9183b254d42d9b2.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '204a1af1c74dcc4bccc245a943c44299',
      'native_key' => 'mail_dkim_passphrase',
      'filename' => 'MODX/Revolution/modSystemSetting/ea618b0b233835c0b0bdd433d1974484.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '25e6118ccaa6020cb5e8ea3c698cbec0',
      'native_key' => 'manager_date_format',
      'filename' => 'MODX/Revolution/modSystemSetting/71e801937b24497695d99f48646db76a.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4f37ddbed3cf6ec172dbcff01712f652',
      'native_key' => 'manager_favicon_url',
      'filename' => 'MODX/Revolution/modSystemSetting/dcbcedf4f7ca1784c15622f816e9f52c.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '252238740b09783ce7af0792706b1370',
      'native_key' => 'manager_time_format',
      'filename' => 'MODX/Revolution/modSystemSetting/d013991d54f956aed9f92201a68b002c.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7be4a87a4f0076525ae880755d9f72e9',
      'native_key' => 'manager_datetime_separator',
      'filename' => 'MODX/Revolution/modSystemSetting/02042faea504578ab6811f64de2f338d.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7f4c4cca16134a64b0bdeae2428af163',
      'native_key' => 'manager_datetime_empty_value',
      'filename' => 'MODX/Revolution/modSystemSetting/4f1937a108f2f9bfef10f9e75cdd0da3.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '78ec42681ca1aeb33cbcb6b69943db70',
      'native_key' => 'manager_direction',
      'filename' => 'MODX/Revolution/modSystemSetting/217df874a1067a7f84cd778f946dc2f1.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4fb4719f0f8c2722821fc48e858b9026',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'MODX/Revolution/modSystemSetting/9d89efef84fc127132a1d736f0b1c047.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dcd5a2dbb496bf5d1a463a28133e81b6',
      'native_key' => 'manager_tooltip_enable',
      'filename' => 'MODX/Revolution/modSystemSetting/c07aff07cdf8802c938383332860397f.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8abd60a6ad99cdf91e3b2d9213011fd2',
      'native_key' => 'manager_tooltip_delay',
      'filename' => 'MODX/Revolution/modSystemSetting/181980422fa57785159498171c5b01a3.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '030ca02ff71e9d5a58bcb5b9ca0249df',
      'native_key' => 'login_background_image',
      'filename' => 'MODX/Revolution/modSystemSetting/b0ec3e9391c72b56d044a0adb31e43b5.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'daba93697d38ff55349db0e52671e4fe',
      'native_key' => 'login_logo',
      'filename' => 'MODX/Revolution/modSystemSetting/7f0c11c86f9f7349b4fb23c30a14bcd6.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '90844aae787949edd06184040647b3ef',
      'native_key' => 'login_help_button',
      'filename' => 'MODX/Revolution/modSystemSetting/e7d6f9b6c7005f958509a44074449c20.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd1ea997ef9a1b9c59762665a53777044',
      'native_key' => 'manager_theme',
      'filename' => 'MODX/Revolution/modSystemSetting/5b7ff39b0cba6a9268a7b18855647e7a.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7f90c55fb5c62ef4c2c72639cb895a01',
      'native_key' => 'manager_logo',
      'filename' => 'MODX/Revolution/modSystemSetting/41b83e7b1f44f8120aae5d8bbdfb7ec1.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4c5fdbb5d578c4cb26b6e6c58d5e93fb',
      'native_key' => 'manager_week_start',
      'filename' => 'MODX/Revolution/modSystemSetting/21c0471ea3121053b8e3e0e9b72c4c17.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ae4faa0ea73b9b04bf0a753cc2c05044',
      'native_key' => 'enable_template_picker_in_tree',
      'filename' => 'MODX/Revolution/modSystemSetting/0037f37e42a050f1989831ab661e10d4.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b9e53801d5d22824cc3969a974e3c73b',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'MODX/Revolution/modSystemSetting/7d38cdb0836b5b21ce852dcfce58ec0b.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '87f3d331971b69eb76972ce7a9876622',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'MODX/Revolution/modSystemSetting/c0d0cc08a8b00e509f6b0beaa824b478.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f845af202a734255942b7581287d72fb',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/d73d8237b3f29a9661b49b6239df838e.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1242c8f8d0d2f541a05f25bbc65c4c51',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'MODX/Revolution/modSystemSetting/540ae922a5ac0d1fc4f0c2453518cbee.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b6046390f8c4f14cb5718f84e50c19e7',
      'native_key' => 'modx_charset',
      'filename' => 'MODX/Revolution/modSystemSetting/ef6422fe7d81dd0a56c9b98e8eff9d03.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '159f61fd15382104d9fc97b67a65840a',
      'native_key' => 'package_installer_at_top',
      'filename' => 'MODX/Revolution/modSystemSetting/fe819d19dcf65cbd7fa07e2323af82ba.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '76958833f218ed07a479b7407cad3cd3',
      'native_key' => 'principal_targets',
      'filename' => 'MODX/Revolution/modSystemSetting/8323a7bd09edc5beb48840d9c147e412.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '49fd8d59746cfa7e34d5037be52b2218',
      'native_key' => 'proxy_auth_type',
      'filename' => 'MODX/Revolution/modSystemSetting/790abe4f027c606e5f5ebcb871207023.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '05c900fe8164deeb7a7f2b26c8b411fe',
      'native_key' => 'proxy_host',
      'filename' => 'MODX/Revolution/modSystemSetting/3f99269c45a0764c86237f9ecbfe9b6c.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6a9627991942510403dc678a6a47b3d8',
      'native_key' => 'proxy_password',
      'filename' => 'MODX/Revolution/modSystemSetting/63000d9aa421712f86158065042c6892.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fe1c215297d79b0960b27a2504a42ed5',
      'native_key' => 'proxy_port',
      'filename' => 'MODX/Revolution/modSystemSetting/7c783b3e68636557e4ac90de4901c5e0.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8380bffa5020d087f6ee0be7eb9bdf24',
      'native_key' => 'proxy_username',
      'filename' => 'MODX/Revolution/modSystemSetting/60a0e1e039e0f22b6da749ae8b3ec32f.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fe9cfe3e54bb12a68aefff18d55c18ce',
      'native_key' => 'password_generated_length',
      'filename' => 'MODX/Revolution/modSystemSetting/a5690b5ada7a13dc583d315e80a3cf7f.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '000561fc70bcfdaa2fccd97e5942c05b',
      'native_key' => 'password_min_length',
      'filename' => 'MODX/Revolution/modSystemSetting/e54232c85d7655904e1431d0edc7344d.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5b8b2c4d5290f9aec0a314179c946aaf',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'MODX/Revolution/modSystemSetting/7d365fd541f587a5eeff24f82f67eb16.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5f4d126b7993ec9908f1888e85ce9473',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'MODX/Revolution/modSystemSetting/7c6f3e8515d7cd873213b1ec6f226f09.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '21c6d2ff0249a7737eef47b1b8f79cab',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'MODX/Revolution/modSystemSetting/821752d68946c349c7d47f87beaaae20.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '699a2ef92b55f50fcf300e4509069d0e',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'MODX/Revolution/modSystemSetting/77c47c365c012b11ac965e04acb175ab.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7b802456c9a4f094e0013da09d8340f9',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/73625a883a79fd525003eec5803e2964.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8688839540a256fd4e3a8ded0f4cd0e2',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'MODX/Revolution/modSystemSetting/e4e492cf578e3d82a777151b1bf183b5.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '39af0448fb325efad0a1f8c41779c18d',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'MODX/Revolution/modSystemSetting/9790ea82191946092204b385d1d4e762.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8f7657234e007301427304c96b858c8e',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'MODX/Revolution/modSystemSetting/18df3a145e41af591225b1ebed1ab5e4.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fff740882c76a5baf7a168c5953aaad1',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'MODX/Revolution/modSystemSetting/0c096918c7e70011ccb8537a5f4f1353.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0fdff33dfdcfefd1a6e887e822ca958b',
      'native_key' => 'phpthumb_far',
      'filename' => 'MODX/Revolution/modSystemSetting/d2bac62ca7c06747f0c5d699f97858b8.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4eafebf17db6efe3396e9865dda75fa0',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'MODX/Revolution/modSystemSetting/afcc75147dcde9b73f706c81fd77fb7e.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1e4ef8351430e6180630e8f99f587c25',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/f489478763da15a45f1e045ec1fe7434.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8d8e798942b665145a7fb934236c2deb',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'MODX/Revolution/modSystemSetting/72cc49fcef09f3898d3b242f4e67ca03.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'db91431206ef8cf8e8102e8622b93508',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'MODX/Revolution/modSystemSetting/8e75a4660737aeee56bd9bd650a53573.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5a4c93c92bebe28709aacdc40679ccac',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'MODX/Revolution/modSystemSetting/a8ae574b74c851c6a325dbcc91862227.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ffa8c447f35e96c877bef06c31ddc95d',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/d0ca597139367d8b5eb26a05d0fea825.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '38b3e61007a46f070cc204a2834579c0',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'MODX/Revolution/modSystemSetting/452d05dbc22e7e18d3d76243eaf0cb63.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '476e60f7e602de7c447976496f0d9217',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'MODX/Revolution/modSystemSetting/c38cc25610367bd00efb3a4cf44abda5.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ad984c1ba8b98214144b44f06a79a761',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'MODX/Revolution/modSystemSetting/a412eb15a03c3e0b4523d62df7632db4.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '18cf40ac7e5b47170d6cbfe210914e3a',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'MODX/Revolution/modSystemSetting/535f0e45c051952da2b4b35c2c91ac0a.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2f206f8500ae0bbbe25deb58b9bb3e10',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'MODX/Revolution/modSystemSetting/7c68bf1330c8062be08c79e81e91bd8c.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'edd80fa7f24039c9182c27dc0f17965c',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'MODX/Revolution/modSystemSetting/74044fd62a1c835f3dc517abce1675a9.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '233dd59b420dffecd6cf6fdba987e1a1',
      'native_key' => 'publish_default',
      'filename' => 'MODX/Revolution/modSystemSetting/241703d6063a5884504b9f36f04349a2.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '48c4395814e335fbc014d2cc274f0a0f',
      'native_key' => 'quick_search_in_content',
      'filename' => 'MODX/Revolution/modSystemSetting/5a996e88798f35351f37a05aff812ffb.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd992d232f48ae22483ed050ac0382cf0',
      'native_key' => 'quick_search_result_max',
      'filename' => 'MODX/Revolution/modSystemSetting/27ccf58cc98a5bc0b6b3b2bbd49549c0.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f6f75766b5fa8b99a5327188166e057f',
      'native_key' => 'request_controller',
      'filename' => 'MODX/Revolution/modSystemSetting/a2d990cad88b4e3d872ddc1ae8798172.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7baff2066cdd55d7ad1e4fed63052046',
      'native_key' => 'request_method_strict',
      'filename' => 'MODX/Revolution/modSystemSetting/c5edeea0ef70f7422946f61027e859b2.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0062217dc6822a18d5c70b79e15561bd',
      'native_key' => 'request_param_alias',
      'filename' => 'MODX/Revolution/modSystemSetting/8b79e897bc9ffa37e35cd367a2c02c20.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1d7ad978c85a0bc6ccbfd2d857ad8467',
      'native_key' => 'request_param_id',
      'filename' => 'MODX/Revolution/modSystemSetting/c70d8ca10273e58341318d192edc5028.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9deef431c53c1dcb64867fe60360c070',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'MODX/Revolution/modSystemSetting/7ca1f45c80844aa437485b81f887e932.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '69cd0bb1dae5b0293f8e74de68bf3041',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'MODX/Revolution/modSystemSetting/95dc1822474765eaae734f6876bcd442.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c4c8138b934725b2011093bfb12cd79f',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'MODX/Revolution/modSystemSetting/65f39e0d5b1278cdec8beb7732f9a22c.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '326ba41c17ddfab4e01cee6728f804c8',
      'native_key' => 'richtext_default',
      'filename' => 'MODX/Revolution/modSystemSetting/605c07783aab9e8df793645a29eb46a4.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f7dd1ed99a32aac4fa80d4d33dfc0277',
      'native_key' => 'search_default',
      'filename' => 'MODX/Revolution/modSystemSetting/bda746a4f71fb37c0f88140e1b90a903.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bf935ef800b4812d2e4aed90f5708027',
      'native_key' => 'server_offset_time',
      'filename' => 'MODX/Revolution/modSystemSetting/2d25317990fecd36ba8548653e58caa9.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '26f333d4be0b9a708b5a23cc09ba1cdb',
      'native_key' => 'session_cookie_domain',
      'filename' => 'MODX/Revolution/modSystemSetting/2390bdbacd43342242100aacde6d3826.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ee59ec69ba84f686c8d40b2c807f5009',
      'native_key' => 'default_username',
      'filename' => 'MODX/Revolution/modSystemSetting/95bf092d29c316c732a6a574ca79c43d.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ce6bb8cd92f6eb7a478eb91e977c89ea',
      'native_key' => 'anonymous_sessions',
      'filename' => 'MODX/Revolution/modSystemSetting/523c4dab2a4f64c44a132dfda471b9df.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '46d40627ebb7ac9a08f7a0acbea15457',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/c3dfd7f2b6c3d72acd2619640254108e.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1780ab20566bed62578dc172895268ea',
      'native_key' => 'session_cookie_path',
      'filename' => 'MODX/Revolution/modSystemSetting/b6eb0612819671798612b533e4ca3a0b.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2c35f1608e990c43c78ec70de3594a2e',
      'native_key' => 'session_cookie_secure',
      'filename' => 'MODX/Revolution/modSystemSetting/9c1435b60a3515013da6629048bce119.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b46a841abb62a34f3a3de832f4ee8aed',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'MODX/Revolution/modSystemSetting/91661d43759d77f498fd313b1c088477.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '837554ec686d5788862b8431099f9a0c',
      'native_key' => 'session_cookie_samesite',
      'filename' => 'MODX/Revolution/modSystemSetting/f15f5121b96d20b71a2256cc04b79a63.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd87c786eda8d8b2b5026999edc927b12',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/16a4702160dba8494afa1c6d2fd26780.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0456153ed76c791dc5ad67d39e646a6a',
      'native_key' => 'session_handler_class',
      'filename' => 'MODX/Revolution/modSystemSetting/eae37d744ec56123f3dfc670508186fe.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '54b2813b61c609a6afbbf38a90745b53',
      'native_key' => 'session_name',
      'filename' => 'MODX/Revolution/modSystemSetting/6348bb312f9963bfd050d66234163e9d.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ee278a7c132b568fd9d1ff210e0fa062',
      'native_key' => 'set_header',
      'filename' => 'MODX/Revolution/modSystemSetting/16e1be9864f8f20582b03a1ecc1388ae.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a0adf0ed6d1d271498b0976aa13fa0c4',
      'native_key' => 'send_poweredby_header',
      'filename' => 'MODX/Revolution/modSystemSetting/4638ccb1f8950b749a146d10e9f9a26f.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '920886f9981a135e6a2292b24c52016c',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'MODX/Revolution/modSystemSetting/ae8a7ee1a1e7f324a0662e7856dd2dcd.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '50815f34a42b2f2a029ca47de99e1bff',
      'native_key' => 'site_name',
      'filename' => 'MODX/Revolution/modSystemSetting/5fc5795136c6705bcfee4d65e4cd8646.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f84efddb6d948a9b8645e2d84ae446e5',
      'native_key' => 'site_start',
      'filename' => 'MODX/Revolution/modSystemSetting/0134ce76bb09e36222a3dbfa995b2cd7.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7fb269949cbb5a0b7ebdd2630d46dc56',
      'native_key' => 'site_status',
      'filename' => 'MODX/Revolution/modSystemSetting/767547ccc06ea754cde2c2846aed1eef.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9ba91ee3b24500b6e1e7927a25ebf74b',
      'native_key' => 'site_unavailable_message',
      'filename' => 'MODX/Revolution/modSystemSetting/9bef3f1c1b809fcf15458625769717b1.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5ec2f8966addd870b6c2475407188db5',
      'native_key' => 'site_unavailable_page',
      'filename' => 'MODX/Revolution/modSystemSetting/c9ad61892de225d8884d3f3442bfb8ac.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fcb2b6f4ef7ed430fe7437f7f2a062a5',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'MODX/Revolution/modSystemSetting/7b77b249f5198ab4235ee0c7798f35d8.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5bdc6810e7937654f35cde7251948f07',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'MODX/Revolution/modSystemSetting/f1a1626ed9b7c8c18b44e25cad0aafbe.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '352778564df124db68010383234a6ed5',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'MODX/Revolution/modSystemSetting/59fb838e87ab94726d3f9f69185193e9.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5cf076e2b335aca3b52298cf484234a7',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'MODX/Revolution/modSystemSetting/7145045e281b916ec1dd4281b2f866e5.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3902a185f7c39608314a2ae2caa3ba1f',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'MODX/Revolution/modSystemSetting/fa311fbe27eacb0d7085bc28af944f05.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '746264f7b84147f595e6b734ecfb4153',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'MODX/Revolution/modSystemSetting/598b098b2983681b4d2e2b5deb76f154.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7458f6bd79668053bedbba21135832ee',
      'native_key' => 'static_elements_default_category',
      'filename' => 'MODX/Revolution/modSystemSetting/84a416ecb2572fea1dc96e0a16a24d27.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fe25bdd827736546af08c7acfdcad930',
      'native_key' => 'static_elements_basepath',
      'filename' => 'MODX/Revolution/modSystemSetting/f898befc29b6af24a5d0201413e3a15f.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3ec8058c3abf83dfe09fd466eb2b3154',
      'native_key' => 'resource_static_allow_absolute',
      'filename' => 'MODX/Revolution/modSystemSetting/0adb38aea6b07ca8b07a527d00bbb1d2.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a39d587f4ac943778db9f42a1646c1d7',
      'native_key' => 'resource_static_path',
      'filename' => 'MODX/Revolution/modSystemSetting/18605ba8bf844250db88622ab3ec2399.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '06cb8e6ff68b2cd37625b91a75c8d3dd',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'MODX/Revolution/modSystemSetting/f7a308f46f95d1541118ccf9b9bf29fd.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '911ea6b036360c32988f4e0a138fc8cf',
      'native_key' => 'syncsite_default',
      'filename' => 'MODX/Revolution/modSystemSetting/93a542c71246cfa4db64c8ca70229839.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '24d39c76d079732dd458adbc86c61fa3',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'MODX/Revolution/modSystemSetting/ce3a22d16239d0f0b29f0db7aaa2de74.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '20c568261444186c0e31ad555c0e4859',
      'native_key' => 'tree_default_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/d3db2dd9138845123efad1960f48a01a.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '91fa4473f9d3065f79d4675a148571cb',
      'native_key' => 'tree_root_id',
      'filename' => 'MODX/Revolution/modSystemSetting/53aa2ddb1a62f1842a7b6a6fdbc660c3.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '18ec2f84520752f80496fe647b033985',
      'native_key' => 'tvs_below_content',
      'filename' => 'MODX/Revolution/modSystemSetting/c44a13552058d1c623f4f39b2715235a.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '91f39ec343a52257efbf8157da09a961',
      'native_key' => 'unauthorized_page',
      'filename' => 'MODX/Revolution/modSystemSetting/3890c010c6855c483317c8ff81487142.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7d7612e69174d2c4c90ae3b9ecfedcf3',
      'native_key' => 'upload_files',
      'filename' => 'MODX/Revolution/modSystemSetting/3530c4b4190152d8719c415aa4576ba1.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '192516335070e19d499d809c65ad5249',
      'native_key' => 'upload_file_exists',
      'filename' => 'MODX/Revolution/modSystemSetting/559c3993da2043c69bc3ed538732453e.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fcc855d3fc5ccccf3a2ea40edd480fe2',
      'native_key' => 'upload_maxsize',
      'filename' => 'MODX/Revolution/modSystemSetting/84d8e5fbee9c3d11271975035647b736.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b0a6f5a1cf76fe5eb38699f36064740f',
      'native_key' => 'upload_translit',
      'filename' => 'MODX/Revolution/modSystemSetting/2443792c42cdaf0ff4d172faf659d354.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '38704641f1e612c7225d4fa02cab4b32',
      'native_key' => 'upload_translit_restrict_chars_pattern',
      'filename' => 'MODX/Revolution/modSystemSetting/7d2289e6499a7ca5c9e4ecc602c44318.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b20c7ae87990a030fa7b23c9e8bf0ec4',
      'native_key' => 'use_alias_path',
      'filename' => 'MODX/Revolution/modSystemSetting/613df0e352abf5eac62eed935e3b2943.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'aca6670d0cba9115cabf05ff14bd4d61',
      'native_key' => 'use_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/92a728df54cbe576a8b673508c1d013c.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ede5e8ef601f18d24d6951a654c91fdd',
      'native_key' => 'use_multibyte',
      'filename' => 'MODX/Revolution/modSystemSetting/b0a564a7689c2ba42a6f62fd33997bde.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c3ad0dcfdc5e76eb85e0ccb1a3e5c16b',
      'native_key' => 'use_weblink_target',
      'filename' => 'MODX/Revolution/modSystemSetting/1d37475b18798e45d1da1b1ce3eadcf4.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7a42921947b1315f59918c1775009ba3',
      'native_key' => 'welcome_screen',
      'filename' => 'MODX/Revolution/modSystemSetting/21cda39773a3a690144ae40342ff41b9.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '15e91a3919c67a89edec3191ae6124a4',
      'native_key' => 'welcome_screen_url',
      'filename' => 'MODX/Revolution/modSystemSetting/d1ac98c4526d0f927088bf6a7083e77b.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '73f30b44690777d6dbfc9d465c792a18',
      'native_key' => 'welcome_action',
      'filename' => 'MODX/Revolution/modSystemSetting/3c877163f300ee484351074fdb910139.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fb6b0c0a361dc3806a121785520f2fbd',
      'native_key' => 'welcome_namespace',
      'filename' => 'MODX/Revolution/modSystemSetting/c79ca4853437617bcda182daa7df983d.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '17a4eb9083e61e53a0a0cf25421d70b4',
      'native_key' => 'which_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/3db856f38b66ae1b24880ecaa1ba0ca7.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1731d1cacae750ebfda0a155710dee89',
      'native_key' => 'which_element_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/dbcc14b3d340d63ad932e21fe34bd54c.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c71b853b370bbb8ddb832a186e0da68e',
      'native_key' => 'xhtml_urls',
      'filename' => 'MODX/Revolution/modSystemSetting/af9120238f0d388bd199f92c9f69098b.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'deeabb7d7a6c164f3c763bb0deef5e7f',
      'native_key' => 'enable_gravatar',
      'filename' => 'MODX/Revolution/modSystemSetting/6182c56f70e80ee380befa66afba5b36.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8e1570b1611f8b1aab3ac2412e0e1321',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'MODX/Revolution/modSystemSetting/fa923fa8048435759ed0f3f115e928e9.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '533a849eca73ae8c58f10a56e8563203',
      'native_key' => 'mgr_source_icon',
      'filename' => 'MODX/Revolution/modSystemSetting/01f9e74244d15db07a47887dc0b71658.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd92542ccb67a98f476c9644c2e190182',
      'native_key' => 'main_nav_parent',
      'filename' => 'MODX/Revolution/modSystemSetting/1a9f81d55882b93ab93ce60715f6d55d.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '915686fd6e84dc5c88a2dcb24cf3f1be',
      'native_key' => 'user_nav_parent',
      'filename' => 'MODX/Revolution/modSystemSetting/7665ebb8a3ccfd609230d5a0a9717300.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '80a940817c3dd533a60aaa3cfbfbf061',
      'native_key' => 'auto_isfolder',
      'filename' => 'MODX/Revolution/modSystemSetting/2d2ad3b0d5cfb10acb908ad0198806ac.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd25cff92c6192c7e0a7e9f98e62cb605',
      'native_key' => 'manager_use_fullname',
      'filename' => 'MODX/Revolution/modSystemSetting/0d0f6c51b8d0a379c84c182637da513d.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1cb41f17e8b0daec9b6636cc69e30d0d',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'MODX/Revolution/modSystemSetting/2106b55d4ef16d77edd6603f08115a81.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '65098175c816a88e519130a376ac763a',
      'native_key' => 'preserve_menuindex',
      'filename' => 'MODX/Revolution/modSystemSetting/410c191ab3903363363eb758f6655dac.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'eb9f370d44d5eb1f54ad8e8f718c05aa',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'MODX/Revolution/modSystemSetting/ce35e9324cb1b0acb8680bc7987437c5.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3c1f51489258ac5446e16529df0a090f',
      'native_key' => 'error_log_filename',
      'filename' => 'MODX/Revolution/modSystemSetting/8a60b63c234a3f424aaeb8e964f3d6cd.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b40662c5da25a695985a260c5ab86d20',
      'native_key' => 'error_log_filepath',
      'filename' => 'MODX/Revolution/modSystemSetting/fc18e97147d52f2f185290b5385a26c1.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ed3e5115329df29ab8d2424e5bb7e5c9',
      'native_key' => 'passwordless_activated',
      'filename' => 'MODX/Revolution/modSystemSetting/e46b59e12e06f26f3fcc571091af48b2.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0d1ecc103864efcc92f98c4e16040280',
      'native_key' => 'passwordless_expiration',
      'filename' => 'MODX/Revolution/modSystemSetting/d2d8b573874b6e518aa1caa4c53526c5.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9350ce1f67c2101234039099de44ec2f',
      'native_key' => 'static_elements_html_extension',
      'filename' => 'MODX/Revolution/modSystemSetting/ff00d1508388a99e72d3ca27b665d244.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContextSetting',
      'guid' => '44b6c0098d82a709eaa218673e696760',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'MODX/Revolution/modContextSetting/404b35955e38c4877b6f8419e29379f2.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContextSetting',
      'guid' => 'cc04bc30451f5f5e3b3651a2d235765c',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'MODX/Revolution/modContextSetting/1342e606f382d65046d475a4459966af.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroup',
      'guid' => 'e7bcbdb8d391285bdea88e3080369d4b',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modUserGroup/e87245295070a2e28469c3e4625e7932.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboard',
      'guid' => '137ba500431bb83d5f0b5b3f215ae373',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modDashboard/3eda6ed99ce0aecfe3041b29671f888f.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\Sources\\modMediaSource',
      'guid' => '91d899bd066aef9d3ddba62839018365',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/Sources/modMediaSource/aefd1c0d9af3a4ff1ed5cdf7d2c11ad6.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'e004e486ef48e40db46dd331ebf90ced',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/afc25712e79876e3b563b1704fcc98ac.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'b10d96e5c8a69545000d24e2462efb9c',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/c9135eef501298f9db09a090c77e032c.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '1cf7f814a9bbba319a7442536c45a3b5',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/3d88058d56592c3cce01557f8d673669.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '8cb560db04e8fad84ec4038ba96d2d42',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/9a51df085d4a05b9549eccf2e4c2ba12.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '4da8d8f049eedf9cfce8027d8d10d6b4',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/035834d90151b4d492302618d10e49d3.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'aeaf53fb2408e0b52c9212993b31a66d',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/e63b43a01d966e110f4f9c9e330d9353.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '02f1a7d646a7dfd8f2017f2397bdd681',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/7a3ae161e5699eddf8c02f409a883f0b.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroupRole',
      'guid' => '2abc40fbabd2d460b0f77730f52ce95c',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modUserGroupRole/34299d0427ed32c98bfb442c99f22b31.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroupRole',
      'guid' => 'f8e50ec0982f4626cf814ec44c61be41',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modUserGroupRole/92a848d3977db0e4268ee1eedde08626.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '1d0e29dfce149b34d9aa4ac49975d531',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/adbc78ecbcdb8166154a9ba9629a2fc5.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => 'b92380efd7431ee6d4bc63c966eaa8af',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/24906060359d3b3f0950c08ac36c6ec9.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '5ce364e228865b064419b1ff7a3bac86',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/fd4a4234124bc3f75a263589e9dff996.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '43142a78a56a15ae1318ed37ebd88517',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/8dc4f84e8b7a5c5d222330c4f0041e4d.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => 'a847c364fa2c3a6c6bf53eaff3d17b0c',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/ec27c90c52c1c64eb87f69f9a55e5e9b.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '4785e876aad301c936f5b11486b67d3c',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/2b43c10d2853ada9063f19f71b45e2e6.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '9a8da97d93ad77a22dfec149362546e4',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/dbcf3340bb4fb69827f78ae188dc0074.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '54b5fa98cbf0bb634b2ce1b151bd7c63',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/13ca702c991a9c47010c316c77c46620.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '578d1665c313eb4300c793bc1c864644',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/78a835eddff2bb11b4329af929017f92.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '7b92584f5b9a796d46a05e1b9cb27a59',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/2121a1f6b5d812c4c78ea50aed52ebbb.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'fe5397e8e0349ea2aafed38f5eb90e71',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/3c9be690c516a4c46ada881a1d2193c8.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'ab4143df92993b85125a4c73098fb489',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/da17920f13138859704af2c9f5fe6029.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'ddb9225587782cf0e72c66f28232a105',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/1fdfa72bb4410d63255a8befa2319685.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'c41521adb183081aa807b6a36c304c80',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/ac0a0e6dd8dc5060b97a74a1ed41569d.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '349b218bc79f26464ff46acda3e59ea7',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modAccessPolicy/92f6a2921d2fc52c779c52e4a0be9e25.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '6bf14eb8dc68de9c25774d98f0774727',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modAccessPolicy/c25bd1cb38122b95715cb44e202bab39.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'ac21bdb034cacb2a6c875d84f30ab301',
      'native_key' => 3,
      'filename' => 'MODX/Revolution/modAccessPolicy/bc875e44bc26681c3224be7d8b18cabd.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'e99703f51b9f07b658ab475f9ee5dddb',
      'native_key' => 4,
      'filename' => 'MODX/Revolution/modAccessPolicy/8eb424c64e7f08a9cc9b991130704f65.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'ac7e3a62c58379bd7a22f2cce47d9027',
      'native_key' => 5,
      'filename' => 'MODX/Revolution/modAccessPolicy/0b49a931ab0f09a7e6e87bc3458e5fb7.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'd28bd3155b1d061c0cf4a5893a24a9d9',
      'native_key' => 6,
      'filename' => 'MODX/Revolution/modAccessPolicy/c45a1bc0e6bca66b6b33e062a72619cf.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '240c4e3ac8bef05ea3e65ed79295c679',
      'native_key' => 7,
      'filename' => 'MODX/Revolution/modAccessPolicy/5cbeb7f71206d2ba31364747bcd2c98b.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '392d6a37e6adfcbe7967f7fe6180558d',
      'native_key' => 8,
      'filename' => 'MODX/Revolution/modAccessPolicy/305072e2375fc9fda96458e85bd4551d.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'c1b4f19be1d5065d7a12197cf8b250c1',
      'native_key' => 9,
      'filename' => 'MODX/Revolution/modAccessPolicy/14a57e1de362c1e9674883780f211e42.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '93f2483bbd7c32bb88f27f4b8c1cfa23',
      'native_key' => 10,
      'filename' => 'MODX/Revolution/modAccessPolicy/b835d8718383a3f8fbc9e5e30a53efca.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'a139bfe13a9c137ad7c7ee6aef68acb3',
      'native_key' => 11,
      'filename' => 'MODX/Revolution/modAccessPolicy/432f413a8e36f9936baa2335f6dc351e.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'c94285d6ae53f25ab80d0380aa99e7b7',
      'native_key' => 12,
      'filename' => 'MODX/Revolution/modAccessPolicy/6164f02628d02194b7e52d8d40bb6d0c.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContext',
      'guid' => '3fa76cd6e4385c035bb8187837f1ca7f',
      'native_key' => 'web',
      'filename' => 'MODX/Revolution/modContext/13a4e62f8089f0bfd8e6f8ca796a6b90.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContext',
      'guid' => 'ff11a2a0c56a8091d0626f4762c9333c',
      'native_key' => 'mgr',
      'filename' => 'MODX/Revolution/modContext/27a2fa7762944042156a307625cbb836.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '7aec983ca6a7b13c77871e4596b3a8d5',
      'native_key' => '7aec983ca6a7b13c77871e4596b3a8d5',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/007413055e5715bede60429f32361f87.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '8c8a298c6930015ba1e17ecc1022f857',
      'native_key' => '8c8a298c6930015ba1e17ecc1022f857',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/90886432518755144eb7eb9ee146e985.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '37daf9640ad1300e0cfb7aaac1b4d48c',
      'native_key' => '37daf9640ad1300e0cfb7aaac1b4d48c',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/cb928feb1043572ff40c5c75cf9ae8a8.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '3e6982c17c111889feec6561f9ec49aa',
      'native_key' => '3e6982c17c111889feec6561f9ec49aa',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/1a82d8563646f6a88682a586bbbf6b5f.vehicle',
    ),
  ),
);